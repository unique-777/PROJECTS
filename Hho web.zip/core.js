// scripts.js
document.querySelectorAll('.member-info h2').forEach(item => {
    item.addEventListener('click', () => {
        alert('You clicked on ' + item.textContent);
    });
});
