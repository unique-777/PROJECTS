document.addEventListener("DOMContentLoaded", function() {
    // Initialize the Owl Carousel with the correct settings
    $('#slideContainer').owlCarousel({
        items: 1, // Show one slide at a time
        loop: true, // Loop the slides
        nav: true, // Enable next/prev navigation buttons
        dots: true, // Enable dots navigation
        autoplay: true, // Autoplay the slider
        autoplayTimeout: 3000, // Slide change time
        autoplayHoverPause: true, // Pause autoplay when hovering
        smartSpeed: 1000, // Transition speed
        onInitialized: function() {
            // Ensure that the first dot is active on initialization
            $(".owl-dot").eq(0).addClass("active");
        }
    });

    // Bind click event to dots for manual navigation (Owl Carousel already does this)
    $('#slideContainer').on('click', '.owl-dot', function() {
        var index = $(this).index(); // Get the index of the clicked dot
        $('#slideContainer').trigger('to.owl.carousel', [index, 300]); // Navigate to the corresponding slide
    });
});

