document.addEventListener('DOMContentLoaded', () => {
    console.log('HHO News, Events, and Testimonials page loaded');
    // You can add more interactive features here
});
document.addEventListener('DOMContentLoaded', () => {
    // Function to change the color of the HHO heading
    const changeHeadingColor = () => {
        const colors = ['#FF5733', '#33FF57', '#3357FF', '#FF33A6', '#FF8C33', '#A633FF'];
        const heading = document.getElementById('hho-heading');
        let currentColorIndex = 0;

        setInterval(() => {
            heading.style.color = colors[currentColorIndex];
            currentColorIndex = (currentColorIndex + 1) % colors.length;
        }, 500); // Change color every 500 milliseconds
    };

    // Start changing colors
    changeHeadingColor();
});

