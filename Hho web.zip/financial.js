document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('transaction-form');
    const transactionList = document.getElementById('transaction-list');

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const description = document.getElementById('description').value;
        const amount = document.getElementById('amount').value;

        if (description && amount) {
            const listItem = document.createElement('li');
            listItem.textContent = `${description}: $${parseFloat(amount).toFixed(2)}`;
            transactionList.appendChild(listItem);

            // Clear the form fields
            form.reset();
        }
    });
});
