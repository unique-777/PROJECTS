document.addEventListener('DOMContentLoaded', () => {
    const registrationForm = document.getElementById('registration-form');
    const registrationList = document.getElementById('registration-list');
    const registerButtons = document.querySelectorAll('.register-btn');

    // Event registration via the form
    registrationForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const event = document.getElementById('event').value;
        
        if (name && email && event) {
            const listItem = document.createElement('li');
            listItem.textContent = `Name: ${name}, Email: ${email}, Event ID: ${event}`;
            registrationList.appendChild(listItem);

            // Clear the form fields
            registrationForm.reset();
        }
    });

    // Handle event registration button clicks
    registerButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const eventId = e.target.getAttribute('data-event-id');
            const eventTitle = e.target.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.textContent;

            alert(`You clicked to register for: ${eventTitle} (Event ID: ${eventId})`);
        });
    });
});
