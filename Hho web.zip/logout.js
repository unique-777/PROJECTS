document.addEventListener('DOMContentLoaded', function() {
    const logoutYes = document.getElementById('logout-yes');
    const logoutNo = document.getElementById('logout-no');
    const feedbackForm = document.getElementById('feedback-form');

    // Event listener for the "Yes, Logout" button
    logoutYes.addEventListener('click', function() {
        alert('You have been logged out.');
        // Logic to handle logout here, such as redirecting to a login page or logging out the user
        window.location.href = 'login.html'; // Replace with your login page URL
    });

    // Event listener for the "No, Stay Logged In" button
    logoutNo.addEventListener('click', function() {
        // Logic to cancel logout and return to the previous page
        window.history.back();
    });

    // Event listener for the feedback form submission
    feedbackForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent form submission
        const rating = document.querySelector('input[name="star"]:checked')?.value || 'No rating';
        const feedback = document.getElementById('feedback').value;
        alert(`Thank you for your feedback!\nRating: ${rating} Stars\nFeedback: ${feedback}`);
        
        // Clear the form after submission
        feedbackForm.reset();
    });

    // Add animation to stars when clicked
    document.querySelectorAll('.rating label').forEach(label => {
        label.addEventListener('click', function() {
            label.classList.add('fly'); // Add the class for animation
            setTimeout(() => {
                label.classList.remove('fly'); // Remove the class after animation
            }, 500); // Duration of the animation
        });
    });
});

