document.addEventListener('DOMContentLoaded', () => {
    // Data Structures
    let volunteers = [];

    // DOM Elements
    const volunteerForm = document.getElementById('volunteerForm');
    const volunteerTableBody = document.getElementById('volunteerTable').querySelector('tbody');
    const contributorsList = document.querySelector('.contributors-list');
    const volunteerListSection = document.querySelector('.volunteer-list');

    // Event Listener for Adding Volunteers
    volunteerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const role = document.getElementById('role').value;
        const classBatch = document.getElementById('classBatch').value.trim();
        const contributions = parseInt(document.getElementById('contributions').value, 10);

        if (name && email && role && classBatch && !isNaN(contributions)) {
            const volunteer = { name, email, role, classBatch, contributions };
            volunteers.push(volunteer);
            updateVolunteerTable();
            updateTopContributors();
            updateVolunteerList();
            volunteerForm.reset();
        }
    });

    // Function to Update Volunteer Table
    function updateVolunteerTable() {
        volunteerTableBody.innerHTML = '';
        volunteers.forEach((volunteer, index) => {
            const row = document.createElement('tr');

            row.innerHTML = `
                <td>${volunteer.name}</td>
                <td>${volunteer.email}</td>
                <td>${volunteer.role}</td>
                <td>${volunteer.classBatch}</td>
                <td>${volunteer.contributions}</td>
                <td>
                    <button class="edit-btn" onclick="editVolunteer(${index})">Edit</button>
                    <button class="delete-btn" onclick="deleteVolunteer(${index})">Delete</button>
                </td>
            `;

            volunteerTableBody.appendChild(row);
        });
    }

    // Function to Edit Volunteer
    window.editVolunteer = function(index) {
        const volunteer = volunteers[index];
        document.getElementById('name').value = volunteer.name;
        document.getElementById('email').value = volunteer.email;
        document.getElementById('role').value = volunteer.role;
        document.getElementById('classBatch').value = volunteer.classBatch;
        document.getElementById('contributions').value = volunteer.contributions;

        volunteers.splice(index, 1);
        updateVolunteerTable();
        updateTopContributors();
        updateVolunteerList();
    };

    // Function to Delete Volunteer
    window.deleteVolunteer = function(index) {
        volunteers.splice(index, 1);
        updateVolunteerTable();
        updateTopContributors();
        updateVolunteerList();
    };

    // Function to Update Top Contributors
    function updateTopContributors() {
        // Clear current list
        contributorsList.innerHTML = '';

        if (volunteers.length === 0) {
            contributorsList.innerHTML = '<p>No contributors to display.</p>';
            return;
        }

        // Sort volunteers by contributions in descending order
        const sortedVolunteers = [...volunteers].sort((a, b) => b.contributions - a.contributions);

        // Get top 5 contributors
        const topContributors = sortedVolunteers.slice(0, 5);

        topContributors.forEach((volunteer, index) => {
            const card = document.createElement('div');
            card.classList.add('contributor-card');

            card.innerHTML = `
                <h3>${index + 1}. ${volunteer.name}</h3>
                <p><strong>Email:</strong> ${volunteer.email}</p>
                <p><strong>Role:</strong> ${volunteer.role}</p>
                <p><strong>Class & Batch:</strong> ${volunteer.classBatch}</p>
                <p><strong>Contributions:</strong> ${volunteer.contributions}</p>
            `;

            contributorsList.appendChild(card);
        });
    }

    // Function to Update Volunteers & Representatives List Categorized by Class and Batch
    function updateVolunteerList() {
        // Clear current list
        volunteerListSection.innerHTML = '';

        if (volunteers.length === 0) {
            volunteerListSection.innerHTML = '<p>No volunteers to display.</p>';
            return;
        }

        // Group volunteers by Class & Batch
        const grouped = volunteers.reduce((acc, volunteer) => {
            const key = volunteer.classBatch;
            if (!acc[key]) acc[key] = [];
            acc[key].push(volunteer);
            return acc;
        }, {});

        // Create HTML for each group
        for (const [classBatch, groupVolunteers] of Object.entries(grouped)) {
            const groupDiv = document.createElement('div');
            groupDiv.classList.add('class-batch-group');

            groupDiv.innerHTML = `
                <h3>${classBatch}</h3>
                <ul>
                    ${groupVolunteers.map(v => `<li>${v.name} - ${v.email} - ${v.role} - Contributions: ${v.contributions}</li>`).join('')}
                </ul>
            `;

            volunteerListSection.appendChild(groupDiv);
        }
    }

    // Initial Calls to Populate Sections
    updateVolunteerTable();
    updateTopContributors();
    updateVolunteerList();
});
