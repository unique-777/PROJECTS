from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class MobileOTP(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    mobile_number = models.CharField(max_length=15)
    otp = models.CharField(max_length=6, blank=True, null=True)
    is_verified = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user.username} - OTP: {self.otp}"

class Transaction(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_fraud = models.BooleanField(default=False)
    risk_score = models.FloatField(default=0.0)  # add this for ML score
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name="received_transactions")  # Ensure this exists
    is_reversed = models.BooleanField(default=False)  # Add this field to track reversals

    def __str__(self):
        return f"{self.sender} -> {self.recipient}: {self.amount}"


class OTP(models.Model):
    transaction = models.OneToOneField(Transaction, on_delete=models.CASCADE)
    code = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    is_used = models.BooleanField(default=False)

    def is_expired(self):
        return timezone.now() - self.created_at > timezone.timedelta(minutes=5)

    def __str__(self):
        return f"OTP for {self.transaction.id}"


class Payment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=[('completed', 'Completed'), ('failed', 'Failed')])
    created_at = models.DateTimeField(auto_now_add=True)


class ReversalRequest(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    transaction = models.ForeignKey(Transaction, on_delete=models.CASCADE)
    reason = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)


class FraudReport(models.Model):

    user = models.ForeignKey(User, on_delete=models.CASCADE)

    description = models.TextField()

    transaction_id = models.CharField(max_length=255, blank=True, null=True)  # Optional field for transaction ID

    reported_at = models.DateTimeField(auto_now_add=True)


    def __str__(self):

        return f"Fraud Report by {self.user.username} on {self.reported_at}"