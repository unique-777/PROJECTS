import random
from datetime import timedelta
from django.utils import timezone
from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.core.mail import send_mail
from django.contrib.auth.decorators import login_required

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Count, Sum
from .models import MobileOTP, Transaction, OTP, Payment, ReversalRequest, FraudReport
from .fraud_detection import detect_fraudulent_activity
import pandas as pd
from .models import Transaction, FraudReport, Payment
from django.http import JsonResponse

@login_required
def get_transaction_data(request):
    transactions = Transaction.objects.all().values('sender__username', 'recipient__username', 'amount', 'timestamp')
    df = pd.DataFrame(transactions)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    
    # Example: Total amount sent by each sender
    grouped = df.groupby('sender__username')['amount'].sum().reset_index()
    
    return JsonResponse(grouped.to_dict(orient='records'), safe=False)
@login_required
def dashboard(request):
    # Transaction Stats
    transaction_data = Transaction.objects.values('recipient__username').annotate(total_amount=Sum('amount')).order_by('-total_amount')

    # Payment Stats
    payment_data = Payment.objects.values('user__username').annotate(total_payment=Sum('amount')).order_by('-total_payment')

    # Fraud Reports
    fraud_data = FraudReport.objects.values('user__username').annotate(count=Count('id')).order_by('-count')

    context = {
        'transaction_data': list(transaction_data),
        'payment_data': list(payment_data),
        'fraud_data': list(fraud_data)
    }
    return render(request, 'dashboard.html', context)

# --------------------------------------------------
# 🎨 Template Views
# --------------------------------------------------

def index(request):
    return render(request, 'begin.html')

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def reversal_view(request):
    return render(request, 'reversal.html')

def fraud_detection(request):
    return render(request, 'fraud_detection.html')


# --------------------------------------------------
# 👤 User Registration
# --------------------------------------------------

@api_view(['GET', 'POST'])
def register(request):
    if request.method == 'GET':
        return render(request, 'register.html')

    username = request.POST.get('username')
    password = request.POST.get('password')
    name = request.POST.get('name')
    email = request.POST.get('email')
    phone = request.POST.get('phone')

    if User.objects.filter(username=username).exists():
        return Response({'error': 'Username already exists'}, status=400)

    user = User.objects.create_user(username=username, password=password, email=email)
    user.first_name = name
    user.save()

    MobileOTP.objects.create(user=user, mobile_number=phone)
    return render(request,'login.html',{'message': 'User registered successfully'}, status=201)


# --------------------------------------------------
# 🔐 Username/Password Login
# --------------------------------------------------

@api_view(['GET', 'POST'])
def login_user(request):
    if request.method == 'GET':
        return render(request, 'login.html')

    username = request.POST.get('username')
    password = request.POST.get('password')

    user = authenticate(request, username=username, password=password)
    if user:
        login(request, user)
        return render(request, 'makepayment.html', {'message': 'Login successful'})
    return render(request, 'login.html', {'error': 'Invalid credentials'})


# --------------------------------------------------
# 📲 OTP Login (Email-based OTP)
# --------------------------------------------------

@api_view(['POST'])
def send_otp(request):
    username = request.POST.get('username')
    try:
        user = User.objects.get(username=username)
        otp_code = str(random.randint(100000, 999999))
        MobileOTP.objects.update_or_create(user=user, defaults={'otp': otp_code, 'is_verified': False})
        send_mail('Your OTP Code', f'Your OTP is: {otp_code}', 'noreply@fininclusion.com', [user.email],fail_silently=False)
        print(f"OTP sent to {user.email}: {otp_code}") 
        return render(request, 'login.html', {'message': 'OTP sent to your email'})
    except User.DoesNotExist:
        return render(request, 'login.html', {'error': 'User not found'})
    return render(request, 'login.html')


@api_view(['POST'])
def verify_otp(request):
    username = request.POST.get('username')
    entered_otp = request.POST.get('otp')

    # Debugging output
    print("Starting OTP verification process")
    print(f"Username: {username}, Entered OTP: {entered_otp}")

    try:
        # Check if the user exists
        user = User.objects.get(username=username)
        print(f"User  found: {user.username}")

        # Fetch the MobileOTP record for the user
        mobile_otp = MobileOTP.objects.get(user=user)
        print(f"Retrieved User: {user.username}, Stored OTP: {mobile_otp.otp}, Is Verified: {mobile_otp.is_verified}")

        # Check if the entered OTP matches and is not already verified
        if mobile_otp.otp == entered_otp and not mobile_otp.is_verified:
            mobile_otp.is_verified = True
            mobile_otp.save()
            login(request, user)  # Log the user in
            return render(request, 'makepayment.html', {'message': 'OTP verified. User logged in.'})
        else:
            print("Invalid OTP or OTP already verified")
            return render(request, 'login.html', {'error': 'Invalid OTP or User'})

    except User.DoesNotExist:
        print("User  not found")
        return render(request, 'login.html', {'error': 'User  not found'})
    except MobileOTP.DoesNotExist:
        print("OTP not found for this user")
        return render(request, 'login.html', {'error': 'OTP not found for this user.'})
    except Exception as e:
        print(f"An unexpected error occurred: {str(e)}")
        return render(request, 'login.html', {'error': 'An unexpected error occurred'})

    return render(request, 'login.html')
# --------------------------------------------------
# 💸 Make Payment
# --------------------------------------------------

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def make_payment(request):
    if request.method == 'GET':
        return render(request, 'makepayment.html')

    amount = request.POST.get('amount')
    phone_number = request.POST.get('phone_number')

    try:
        recipient = MobileOTP.objects.get(mobile_number=phone_number).user

        # Run fraud detection and get risk score
        risk_score = detect_fraudulent_activity({
            'sender': request.user.username,
            'amount': amount,
        })

        # Decide if the transaction is fraudulent based on risk_score
        is_fraud = risk_score >= 3  # You can adjust this threshold as needed

        # Create transaction and attach risk_score and fraud flag
        txn = Transaction.objects.create(
            sender=request.user,
            recipient=recipient,
            amount=amount,
            risk_score=risk_score,
            is_fraud=is_fraud
        )

        Payment.objects.create(user=request.user, amount=amount, status='completed')

        # Warning if fraud detected
        if is_fraud:
            return render(request, 'makepayment.html', {
                'warning': '⚠️ Potential fraud detected!',
                'transaction_id': txn.id
            })

        return render(request, 'makepayment.html', {
            'message': f'✅ Payment of ₹{amount} to {recipient.username} successful.',
            'transaction_id': txn.id
        })

    except MobileOTP.DoesNotExist:
        return render(request, 'makepayment.html', {'error': 'Recipient not found'})


# --------------------------------------------------
# 🔁 Reversal Request & OTP Confirmation
# --------------------------------------------------

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse
from django.core.mail import send_mail
from .models import Transaction, OTP
import random
from datetime import timedelta
from django.utils import timezone

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def reversal_view(request):
    # Render the reversal request page
    return render(request, 'reversal.html')

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def request_reversal_otp(request):
    txn_id = request.POST.get('transaction_id')

    try:
        txn = Transaction.objects.get(id=txn_id, sender=request.user, is_reversed=False)
        otp_code = str(random.randint(100000, 999999))
        OTP.objects.update_or_create(transaction=txn, defaults={'code': otp_code, 'is_used': False})
        send_mail('Reversal OTP', f'Your OTP for reversal is: {otp_code}', 'noreply@fininclusion.com', [request.user.email])
        return render(request,'reversal.html',{'message': 'Reversal OTP sent to your email'})
    except Transaction.DoesNotExist:
        return Response({'error': 'Invalid or already reversed transaction'}, status=404)

@api_view(['POST'])

@permission_classes([IsAuthenticated])

def confirm_reversal_otp(request):

    txn_id = request.POST.get('transaction_id')

    entered_otp = request.POST.get('otp')


    try:

        # Fetch the transaction based on the provided transaction ID

        txn = Transaction.objects.get(id=txn_id, sender=request.user)


        # Fetch the OTP associated with the transaction

        otp = OTP.objects.get(transaction=txn, code=entered_otp, is_used=False)


        # Check if the OTP has expired

        if timezone.now() - otp.created_at > timedelta(minutes=5):

            return JsonResponse({'error': 'OTP expired'}, status=400)


        # Mark the transaction as reversed

        txn.is_reversed = True

        txn.save()


        # Mark the OTP as used

        otp.is_used = True

        otp.save()


        return JsonResponse({'message': 'Transaction reversed successfully'})


    except Transaction.DoesNotExist:

        return JsonResponse({'error': 'Invalid transaction ID or transaction does not belong to you'}, status=404)

    except OTP.DoesNotExist:

        return JsonResponse({'error': 'Invalid OTP or OTP has already been used'}, status=400)

    except Exception as e:

        return JsonResponse({'error': str(e)}, status=500)

# --------------------------------------------------
# 🚨 Report Fraud
# --------------------------------------------------

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def report_fraud(request):
    description = request.data.get('description')
    if not description:
        return JsonResponse({'error': 'Description is required'}, status=400)

    FraudReport.objects.create(user=request.user, description=description)
    return JsonResponse({'message': 'Fraud report submitted successfully'})


@api_view(['POST'])

@permission_classes([IsAuthenticated])

def submit_fraud_report(request):

    transaction_id = request.POST.get('transaction_id')

    description = request.POST.get('activity_description')  # Ensure this matches the form field name


    if not description:

        return JsonResponse({'error': 'Description is required'}, status=400)


    # Create the fraud report

    FraudReport.objects.create(user=request.user, description=description, transaction_id=transaction_id)


    return JsonResponse({'message': 'Fraud report submitted successfully'})

def detect_fraudulent_activity(transaction_data):
    """
    Simple fraud detection logic:
    Flag large transactions or repetitive ones
    """
    amount = float(transaction_data.get('amount', 0))
    sender = transaction_data.get('sender')

    risk_score=0

    if amount > 10000:  # Threshold example
        risk_score=risk_score+1
        return risk_score

    # Extend with actual ML model or pattern logic here
    return False
# views.py
def dashboard_view(request):
    transactions = Transaction.objects.all()

    transaction_data = [
        {
            'username': t.sender.username if t.sender else 'Unknown',
            'amount': float(t.amount),
            'date': t.timestamp.strftime('%Y-%m-%d'),
            'label': f"{t.sender.username if t.sender else 'Unknown'} ({t.timestamp.strftime('%Y-%m-%d')})",
            'risk_score': round(t.risk_score, 3)
        }
        for t in transactions
    ]

    fraud_count = transactions.filter(is_fraud=True).count()
    legit_count = transactions.filter(is_fraud=False).count()

    return render(request, 'dashboard.html', {
        'transaction_data': transaction_data,
        'fraud_stats': {'fraud': fraud_count, 'legit': legit_count}
    })
