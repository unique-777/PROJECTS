from sklearn.ensemble import IsolationForest
import pandas as pd
from .models import Transaction

def calculate_risk_scores():
    qs = Transaction.objects.all().values('id', 'amount')
    df = pd.DataFrame(list(qs))

    if df.empty:
        return

    model = IsolationForest(contamination=0.1)
    model.fit(df[['amount']])
    scores = model.decision_function(df[['amount']])
    risks = max(scores) - scores  # Normalize

    for index, row in df.iterrows():
        transaction = Transaction.objects.get(id=row['id'])
        transaction.risk_score = round(float(risks[index]), 3)
        transaction.save()
