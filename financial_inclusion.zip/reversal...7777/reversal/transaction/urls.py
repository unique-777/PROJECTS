from django.urls import path
from . import views
from .views import verify_otp

urlpatterns = [
    # 🎨 Template Pages
    path('', views.index, name='home'),
    path('reversal/', views.reversal_view, name='reversal'),
    path('fraud_detection/', views.fraud_detection, name='fraud_detection'),

    # 👤 User Authentication
    path('register/', views.register, name='register'),
    path('login/', views.login_user, name='login_user'),
    path('otp/send/', views.send_otp, name='send_otp'),
    path('otp/verify/', views.verify_otp, name='verify_otp'),

    # 💸 Payments
    path('make_payment/', views.make_payment, name='make_payment'),

    # 🔁 Reversals
    path('reversal/request_otp/', views.request_reversal_otp, name='request_reversal_otp'),
    path('reversal/confirm_otp/', views.confirm_reversal_otp, name='confirm_reversal_otp'),

    # 🚨 Fraud
    path('report_fraud/', views.report_fraud, name='report_fraud'),
    path('submit_fraud_report/', views.submit_fraud_report, name='submit_fraud_report'),
     path('dashboard/', views.dashboard_view, name='dashboard'),
    path('get_transaction_data/', views.get_transaction_data, name='get_transaction_data'),
]
