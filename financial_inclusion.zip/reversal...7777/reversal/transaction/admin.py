from django.contrib import admin
#from .models import CustomUser
from .models import MobileOTP,Transaction,OTP,ReversalRequest,Payment,FraudReport

admin.site.register(Transaction)
admin.site.register(Payment)
admin.site.register(ReversalRequest)
admin.site.register(OTP)
admin.site.register(FraudReport)
admin.site.register(MobileOTP)
#admin.site.register(CustomUser)
# Register your models here.
