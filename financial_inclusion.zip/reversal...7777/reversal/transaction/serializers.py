from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Transaction, OTP, FraudReport
from .models import Payment, ReversalRequest

class ReversalRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReversalRequest
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']

class TransactionSerializer(serializers.ModelSerializer):
    sender = UserSerializer(read_only=True)
    recipient = UserSerializer(read_only=True)

    class Meta:
        model = Transaction
        fields = ['id', 'sender', 'recipient', 'amount', 'timestamp', 'is_reversed']

class OTPSerializer(serializers.ModelSerializer):
    class Meta:
        model = OTP
        fields = ['transaction', 'code', 'created_at', 'is_used']

class FraudReportSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = FraudReport
        fields = ['id', 'user', 'description', 'created_at']

class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'password']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            password=validated_data['password']
        )
        return user

class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = ['amount', 'card_number', 'expiry', 'cvv']
