// Helper function to validate email format
function isValidEmail(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

// Helper function to validate phone number format (10 digits)
function isValidPhone(phone) {
  const regex = /^\d{10}$/;
  return regex.test(phone);
}

// Simulate sending OTP
function sendOTP(type) {
  const inputField = document.getElementById(`${type}-input`);
  const value = inputField.value.trim();

  if (!value) {
    alert('Please enter your phone number or email.');
    inputField.classList.add('input-error');
    return;
  }

  if (value.includes('@')) {
    if (!isValidEmail(value)) {
      alert('Invalid email address.');
      inputField.classList.add('input-error');
      return;
    }
  } else {
    if (!isValidPhone(value)) {
      alert('Phone number should be 10 digits.');
      inputField.classList.add('input-error');
      return;
    }
  }

  inputField.classList.remove('input-error');
  alert(`OTP sent to ${value}`);
}

// Register Form Validation
function validateRegisterForm(form) {
  const name = form.querySelector('input[name="name"]').value.trim();
  const email = form.querySelector('input[name="email"]').value.trim();
  const phone = form.querySelector('input[name="phone"]').value.trim();

  if (!name || !email || !phone) {
    alert('All fields are required.');
    return false;
  }

  if (!isValidEmail(email)) {
    alert('Invalid email address.');
    return false;
  }

  if (!isValidPhone(phone)) {
    alert('Phone number should be 10 digits.');
    return false;
  }

  return true;
}

// Login Form Validation
function validateLoginForm(form) {
  const identifier = form.querySelector('input[name="email_or_phone"]').value.trim();
  const otp = form.querySelector('input[name="otp"]').value.trim();

  if (!identifier || !otp) {
    alert('Both Email/Phone and OTP are required.');
    return false;
  }

  if (identifier.includes('@') && !isValidEmail(identifier)) {
    alert('Invalid email address.');
    return false;
  }

  if (!identifier.includes('@') && !isValidPhone(identifier)) {
    alert('Invalid phone number.');
    return false;
  }

  if (otp.length < 4) {
    alert('OTP must be at least 4 digits.');
    return false;
  }

  return true;
}

// Generic form validation handler
document.addEventListener('DOMContentLoaded', () => {
  const forms = document.querySelectorAll('form');

  forms.forEach(form => {
    form.addEventListener('submit', function (e) {
      const action = form.getAttribute('action');

      let isValid = true;
      if (action.includes('register')) {
        isValid = validateRegisterForm(form);
      } else if (action.includes('login')) {
        isValid = validateLoginForm(form);
      }

      if (!isValid) {
        e.preventDefault();
        return;
      }

      // Optional: Remove preventDefault if you want actual submission
      // e.preventDefault();
      // alert('Form submitted successfully!');
    });
  });
});
