def detect_fraudulent_activity(transaction_data):
    """
    Simple fraud detection logic:
    Flag large transactions or repetitive ones
    """
    amount = float(transaction_data.get('amount', 0))
    sender = transaction_data.get('sender')

    if amount > 10000:  # Threshold example
        return True

    # Extend with actual ML model or pattern logic here
    return False
