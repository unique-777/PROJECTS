from django.db import models

class TravelQuery(models.Model):
    place = models.CharField(max_length=200, blank=True, null=True)
    latitude = models.FloatField(blank=True, null=True)
    longitude = models.FloatField(blank=True, null=True)

    weather_json = models.JSONField(null=True, blank=True)
    risk = models.CharField(max_length=20)
    scam_label = models.CharField(max_length=50)
    women_safety_score = models.IntegerField()

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        if self.place:
            return f"Query: {self.place} ({self.created_at.date()})"
        return f"Query: {self.latitude},{self.longitude}"
