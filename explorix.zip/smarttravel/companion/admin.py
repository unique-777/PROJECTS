from django.contrib import admin
from .models import TravelQuery

@admin.register(TravelQuery)
class TravelQueryAdmin(admin.ModelAdmin):
    list_display = ("place", "latitude", "longitude", "risk", "scam_label", "women_safety_score", "created_at")
    search_fields = ("place", "risk", "scam_label")
    list_filter = ("risk", "scam_label", "created_at")