import requests
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

GEOAPIFY_KEY = settings.GEOAPIFY_API_KEY
OPENWEATHER_KEY = settings.OPENWEATHER_API_KEY

# --------------------------------------------------------------------
# ---------------------- HEALTH RISK (REAL-TIME ONLY) ----------------
# --------------------------------------------------------------------
def health_risk_from_weather(temp_c, humidity):
    try:
        temp = float(temp_c)
        hum = float(humidity)
    except:
        return "Unknown"

    if temp > 40 or hum > 85:
        return "Very High"
    if temp > 38 or hum > 80:
        return "High"
    if temp > 30 or hum > 60:
        return "Medium"
    return "Low"


# --------------------------------------------------------------------
# ---------------------- PACKING LIST (REAL-TIME LOGIC) --------------
# --------------------------------------------------------------------
def packing_list_for_weather(temp, humidity, condition):
    if temp is None or humidity is None or condition is None:
        return []

    items = []
    cond = condition.lower()

    # Temperature-based
    if temp > 38:
        items += [
            "Loose cotton clothing", "Sunscreen SPF 50+",
            "UV sunglasses", "Sun hat", "Cap", "Electrolyte packets",
            "Cooling towel", "Water bottle"
        ]
    elif 32 < temp <= 38:
        items += ["Light cotton clothes", "Sunscreen", "Sunglasses", "Cap", "Hydration bottle"]
    elif 25 < temp <= 32:
        items += ["Light clothing", "Deodorant", "Cap"]
    elif 15 <= temp <= 25:
        items += ["Full-sleeve clothing", "Light jacket", "Sneakers"]
    elif 8 <= temp < 15:
        items += ["Warm jacket", "Sweater", "Woolen socks", "Cap"]
    else:
        items += ["Heavy jacket", "Thermals", "Gloves", "Snow boots"]

    # Rain/Snow
    if any(r in cond for r in ["rain", "drizzle", "thunderstorm"]):
        items += ["Umbrella", "Raincoat", "Waterproof shoes", "Quick-dry clothes"]

    if "snow" in cond:
        items += ["Snow boots", "Hand gloves", "Heavy woolens", "Heat packs"]

    # Humidity-based
    if humidity > 80:
        items += ["Extra T-shirts", "Towel", "Face wipes"]
    elif 60 < humidity <= 80:
        items += ["Extra water bottle"]

    # Universal essentials
    items += [ "Basic first-aid kit", "Hand sanitizer"]

    # Remove duplicates
    return list(dict.fromkeys(items))


# --------------------------------------------------------------------
# ---------------------- SCAM DETECTOR (OFFLINE) ---------------------
# --------------------------------------------------------------------
def scam_detector_from_text(text):
    scam_keywords = ["fraud", "scam", "fake", "cheat", "cheating", "ripoff", "overcharge", "duplicate", "counterfeit"]
    found = [w for w in scam_keywords if w in text.lower()]
    return {"label": "High risk" if found else "Low risk", "found": found}


# --------------------------------------------------------------------
# ---------------------- WOMEN SAFETY SCORE (OFFLINE) ---------------
# --------------------------------------------------------------------
def women_safety_score(city):
    if not city:
        return 50

    c = city.lower()
    very_unsafe = ["delhi", "johannesburg", "rio", "mexico city"]
    if any(x in c for x in very_unsafe):
        return 35

    metro = ["mumbai", "kolkata", "chennai", "tokyo", "new york", "london"]
    if any(x in c for x in metro):
        return 50

    tier1 = ["hyderabad", "bengaluru", "bangalore", "pune", "singapore"]
    if any(x in c for x in tier1):
        return 70

    tourist = ["goa", "bali", "pattaya", "bangkok", "phuket"]
    if any(x in c for x in tourist):
        return 55

    hills = ["manali", "shimla", "ooty", "nainital", "darjeeling", "gangtok"]
    if any(x in c for x in hills):
        return 85

    tier2 = ["jaipur", "surat", "kochi", "indore", "bhopal", "ahmedabad"]
    if any(x in c for x in tier2):
        return 75

    return 65
# ---------------------- MOOD SUGGESTIONS + NEARBY ------------------

def mood_suggestion(lat=None, lon=None, max_places=5):
    """
    Returns a list of historic/must-visit landmarks:
    - Fetches real historic sites nearby using Geoapify.
    - Minimal fallback if API fails.
    """
    # Minimal fallback (only if API fails completely)
    fallback_landmarks = [
        "Ancient Fort",
        "Famous Temple"
    ]

    # If lat/lon or API key not available, return minimal fallback
    if lat is None or lon is None or not GEOAPIFY_KEY:
        return {"text_suggestions": fallback_landmarks}

    try:
        url = (
            f"https://api.geoapify.com/v2/places?"
            f"categories=natural,heritage,tourism&"
            f"filter=circle:{lon},{lat},5000&"
            f"bias=proximity:{lon},{lat}&"
            f"limit={max_places}&"
            f"lang=en&"
            f"apiKey={GEOAPIFY_KEY}"
        )

        r = requests.get(url, timeout=10)
        r.raise_for_status()
        data = r.json()
        features = data.get("features", [])

        geo_places = []
        for f in features:
            props = f.get("properties", {})
            name = props.get("name")
            categories = props.get("categories", "")

            # Normalize categories to string
            if isinstance(categories, list):
                categories = " ".join(categories)
            elif not isinstance(categories, str):
                categories = ""

            categories_lower = categories.lower()
            # Keep only historic places, museums, or monuments
            if name and any(k in categories_lower for k in [ "tourism", "natural", "heritage","attraction", "monument"]):
                geo_places.append(name)

        # If Geoapify returned nothing, use minimal fallback
        if not geo_places:
            geo_places = fallback_landmarks

        # Remove duplicates and return
        combined = list(dict.fromkeys(geo_places))
        return {"text_suggestions": combined}

    except Exception as e:
        logger.error(f"❌ GEOAPIFY ERROR: {e}")
        return {"text_suggestions": fallback_landmarks}
