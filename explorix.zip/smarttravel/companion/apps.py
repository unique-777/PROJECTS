from django.apps import AppConfig

class CompanionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "companion"
