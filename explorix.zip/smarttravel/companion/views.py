# views.py
import json
import requests
import logging
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from . import ai_utils
from .models import TravelQuery  # Import your model

logger = logging.getLogger(__name__)
OPENWEATHER_KEY = settings.OPENWEATHER_API_KEY
GEOAPIFY_KEY = settings.GEOAPIFY_API_KEY

def index(request):
    return render(request, "companion/index.html")


# ---------------- Reverse Geocode ----------------
def api_reverse_geocode(request):
    lat = request.GET.get("lat")
    lon = request.GET.get("lon")
    if not lat or not lon:
        return JsonResponse({"error": "lat and lon required"}, status=400)

    try:
        url = f"https://api.bigdatacloud.net/data/reverse-geocode-client?latitude={lat}&longitude={lon}&localityLanguage=en"
        r = requests.get(url, timeout=7)
        r.raise_for_status()
        data = r.json()
        city = data.get("city") or data.get("locality") or data.get("principalSubdivision") or None
        return JsonResponse({"city": city})
    except Exception as e:
        logger.error(f"Reverse geocode failed: {e}")
        return JsonResponse({"error": "geocode failed", "detail": str(e)}, status=500)


# ---------------- Main Analyzer ----------------
@csrf_exempt
def api_analyze(request):
    if request.method != "POST":
        return JsonResponse({"error": "POST only"}, status=405)

    try:
        body = json.loads(request.body.decode("utf-8") or "{}")
    except:
        body = {}

    place = body.get("place")
    lat = body.get("lat")
    lon = body.get("lon")

    # Convert lat/lon
    try:
        lat = float(lat) if lat not in [None, ""] else None
        lon = float(lon) if lon not in [None, ""] else None
    except:
        lat = None
        lon = None

    if not OPENWEATHER_KEY:
        return JsonResponse({"error": "OpenWeather API key missing"}, status=500)

    # ---------------- Forward geocode if only place is given ----------------
    if (lat is None or lon is None) and place and GEOAPIFY_KEY:
        try:
            fwd = requests.get(
                f"https://api.geoapify.com/v1/geocode/search?text={requests.utils.requote_uri(place)}&apiKey={GEOAPIFY_KEY}",
                timeout=7
            )
            fwd.raise_for_status()
            data = fwd.json()
            if data.get("features"):
                lon = data["features"][0]["properties"]["lon"]
                lat = data["features"][0]["properties"]["lat"]
        except Exception as e:
            logger.error(f"Forward geocode failed: {e}")

    # ---------------- Fetch weather ----------------
    try:
        if place:
            url = f"https://api.openweathermap.org/data/2.5/weather?q={requests.utils.requote_uri(place)}&appid={OPENWEATHER_KEY}&units=metric"
        elif lat is not None and lon is not None:
            url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={OPENWEATHER_KEY}&units=metric"
        else:
            return JsonResponse({"error": "place or (lat, lon) required"}, status=400)

        r = requests.get(url, timeout=10)
        r.raise_for_status()
        weather = r.json()
    except Exception as e:
        logger.error(f"Weather fetch failed: {e}")
        return JsonResponse({"error": "weather fetch failed", "detail": str(e)}, status=500)

    main = weather.get("main", {})
    temp = main.get("temp")
    humidity = main.get("humidity")
    condition = weather.get("weather", [{}])[0].get("main", "")

    # Resolve city name if missing
    city_name = place
    if not city_name and lat and lon:
        try:
            rr = requests.get(
                f"https://api.bigdatacloud.net/data/reverse-geocode-client?latitude={lat}&longitude={lon}&localityLanguage=en",
                timeout=6,
            )
            rr.raise_for_status()
            geo = rr.json()
            city_name = geo.get("city") or geo.get("locality") or geo.get("principalSubdivision") or None
        except Exception as e:
            logger.error(f"Reverse geocode failed: {e}")
            city_name = None

    # ---------------- Process AI utils ----------------
    health_risk = ai_utils.health_risk_from_weather(temp, humidity)
    packing = ai_utils.packing_list_for_weather(temp, humidity, condition)
    mood_data = ai_utils.mood_suggestion(lat=lat, lon=lon, max_places=5)
    mood_suggestions = mood_data.get("text_suggestions", [])
    scam = ai_utils.scam_detector_from_text(weather.get("weather", [{}])[0].get("description", ""))
    women_safety = ai_utils.women_safety_score(city_name)

    # ---------------- Save the query to DB ----------------
    TravelQuery.objects.create(
        place=city_name,
        latitude=lat,
        longitude=lon,
        risk=health_risk,
        scam_label=scam.get("label"),
        women_safety_score=women_safety
    )

    # ---------------- Return response ----------------
    return JsonResponse({
        "weather": weather,
        "city": city_name,
        "computed": {
            "health_risk": health_risk,
            "packing_list": packing,
            "mood_suggestions": mood_suggestions,
            "scam": scam,
            "women_safety_score": women_safety,
        }
    })
