# companion/urls.py
from django.urls import path
from . import views
from django.contrib import admin
urlpatterns = [
    path("", views.index, name="index"),
    path("api_reverse_geocode/", views.api_reverse_geocode, name="api_reverse_geocode"),
    path("api_analyze/", views.api_analyze, name="api_analyze"),
    
]
