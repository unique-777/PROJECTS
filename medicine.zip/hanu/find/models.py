from django.db import models

class Medicine(models.Model):
    name = models.CharField(max_length=255)
    brand_name = models.CharField(max_length=255, null=True, blank=True)
    composition = models.TextField(null=True, blank=True)
    price = models.CharField(max_length=100, null=True, blank=True)
    description = models.TextField(null=True, blank=True)  # Ensure this field exists
    source = models.CharField(max_length=50, default="Database")

    def __str__(self):
        return self.name
