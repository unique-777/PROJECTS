function searchMedicine() {
    const query = document.getElementById("medicineSearch").value;
    fetch(`/api/search/?q=${query}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById("results").innerHTML = JSON.stringify(data, null, 2);
        })
        .catch(error => console.log("Error fetching data:", error));
}

