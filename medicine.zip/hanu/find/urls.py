from django.urls import path
from .views import search_medicine, home,fetch_medicine_info  # Ensure both functions are imported

urlpatterns = [
    path('api/search/', search_medicine, name='search_medicine'),
    path('', home, name='home'),
    path("medicine/<str:medicine_name>/", fetch_medicine_info, name="fetch_medicine_info"),
]
