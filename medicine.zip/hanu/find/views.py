from django.shortcuts import render
from django.http import JsonResponse
from .models import Medicine
import requests
from bs4 import BeautifulSoup

def home(request):
    return render(request, 'index.html')  # Ensure 'index.html' exists in the templates folder

def search_medicine(request):
    query = request.GET.get('q', '').lower()
    
    if not query:
        return JsonResponse({"error": "No search query provided"}, status=400)
    
    # Check if the medicine is in the database
    medicine = Medicine.objects.filter(name__icontains=query).first()
    if medicine:
        return JsonResponse({
            "name": medicine.name,
            "price": medicine.price,
            "brand": medicine.brand_name,
            "source": medicine.source
        })

    # Fetch from OpenFDA API
    api_url = f"https://api.fda.gov/drug/label.json?search=openfda.brand_name:{query}"
    response = requests.get(api_url)

    if response.status_code == 200:
        try:
            data = response.json()
            if "results" in data and data["results"]:
                name = data["results"][0].get("openfda", {}).get("brand_name", ["Unknown"])[0]
                composition = data["results"][0].get("active_ingredient", ["Unknown"])[0]
                price = scrape_medicine_prices(name)

                # Store in database
                Medicine.objects.update_or_create(
                    name=name,
                    defaults={"composition": composition, "brand_name": name, "price": price, "source": "API"}
                )

                return JsonResponse({
                    "name": name,
                    "composition": composition,
                    "price": price,
                    "source": "API"
                })
        except Exception as e:
            return JsonResponse({"error": f"Error parsing API response: {str(e)}"}, status=500)

    return JsonResponse({"error": "No data found from OpenFDA"}, status=404)


def scrape_medicine_prices(name):
    url = f"https://www.examplepharmacy.com/search?q={name}"
    headers = {"User-Agent": "Mozilla/5.0"}

    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()  # Raise an error for bad responses (4xx/5xx)
        
        # TODO: Parse the price properly here (depends on website structure)
        soup = BeautifulSoup(response.text, 'html.parser')
        price_element = soup.find("span", class_="price")  # Update selector based on actual HTML
        
        if price_element:
            return price_element.text.strip()
        else:
            return "Price not found"
    
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data: {e}")
        return "Price unavailable"


def fetch_medicine_info(request, medicine_name):
    api_url = f"https://api.fda.gov/drug/label.json?search=openfda.brand_name:{medicine_name}"
    response = requests.get(api_url)
    
    if response.status_code == 200:
        data = response.json()
        if "results" in data:
            try:
                medicine_info = data["results"][0]
                description = medicine_info.get("description", ["No description available"])[0]
                
                # Store/update in database
                Medicine.objects.update_or_create(
                    name=medicine_name,
                    defaults={"description": description, "source": "OpenFDA"},
                )
                
                return JsonResponse({"name": medicine_name, "description": description})
            except KeyError as e:
                return JsonResponse({"error": f"Invalid API response structure: {e}"}, status=500)
    
    return JsonResponse({"error": "Medicine not found"}, status=404)
