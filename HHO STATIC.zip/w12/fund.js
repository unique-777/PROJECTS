  // Sample data for authorized users
        const users = {
            "NAYANAPALLI VENKATA JAHNAVI": "jahnavi",
            "representative1": "jahnavi"
        };

        // Get user contributions from localStorage or initialize if not present
        let userContributions = JSON.parse(localStorage.getItem("userContributions")) || {};

        function authenticateUser(event) {
            event.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            if (users[username] === password) {
                document.getElementById('loginPage').style.display = 'none';
                document.getElementById('dashboardPage').style.display = 'block';
                // Initialize or reset user data
                if (!userContributions[username]) {
                    userContributions[username] = {
                        totalContributions: 0,
                        monthlyCollections: Array(12).fill(0),
                        yearlyCollections: [0]
                    };
                }
                drawHHOChart('monthly');
                drawBranchClassCharts('monthly');
            } else {
                document.getElementById('errorMessage').style.display = 'block';
            }
        }

        function handleFormSubmit(event) {
            event.preventDefault();
            const username = document.getElementById('contributorName').value;
            const contributionAmount = parseFloat(document.getElementById('contributionAmount').value);
            const date = new Date(document.getElementById('contributionDate').value);
            const month = date.getMonth();
            const year = date.getFullYear();

            // Update user contribution data
            if (userContributions[username]) {
                userContributions[username].totalContributions += contributionAmount;
                userContributions[username].monthlyCollections[month] += contributionAmount;
                userContributions[username].yearlyCollections[0] += contributionAmount;
            } else {
                userContributions[username] = {
                    totalContributions: contributionAmount,
                    monthlyCollections: Array(12).fill(0),
                    yearlyCollections: [contributionAmount]
                };
                userContributions[username].monthlyCollections[month] = contributionAmount;
            }

            // Store data in localStorage
            localStorage.setItem("userContributions", JSON.stringify(userContributions));

            // Update total collected
            document.getElementById('totalCollected').innerText = `$${userContributions[username].totalContributions.toFixed(2)}`;

            // Redraw charts based on selected period
            drawHHOChart(document.querySelector('.toggle-buttons button.active').id.includes('monthly') ? 'monthly' : 'yearly');
            drawBranchClassCharts(document.querySelector('.toggle-buttons button.active').id.includes('branchMonthly') ? 'monthly' : 'yearly');
        }

        function drawHHOChart(period) {
            const ctx = document.getElementById('hhoChart').getContext('2d');
            const chartData = period === 'monthly' ? userContributions['NAYANAPALLI VENKATA JAHNAVI'].monthlyCollections : userContributions['NAYANAPALLI VENKATA JAHNAVI'].yearlyCollections;
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: period === 'monthly' ? ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] : ['This Year'],
                    datasets: [{
                        label: 'Contributions ($)',
                        data: chartData,
                        backgroundColor: 'rgba(0, 123, 255, 0.5)',
                        borderColor: 'rgba(0, 123, 255, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        function drawBranchClassCharts(period) {
            const ctxBranch = document.getElementById('branchChart').getContext('2d');
            const ctxClass = document.getElementById('classChart').getContext('2d');

            // Sample mock data for branch and class charts
            const branchData = [50, 150, 200, 100]; // Example branch contributions
            const classData = [100, 200, 50, 70];  // Example class contributions

            // Draw Branch Chart
            new Chart(ctxBranch, {
                type: 'bar',
                data: {
                    labels: ['Branch 1', 'Branch 2', 'Branch 3', 'Branch 4'],
                    datasets: [{
                        label: 'Branch Contributions ($)',
                        data: branchData,
                        backgroundColor: 'rgba(0, 123, 255, 0.5)',
                        borderColor: 'rgba(0, 123, 255, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Draw Class Chart
            new Chart(ctxClass, {
                type: 'bar',
                data: {
                    labels: ['Class A', 'Class B', 'Class C', 'Class D'],
                    datasets: [{
                        label: 'Class Contributions ($)',
                        data: classData,
                        backgroundColor: 'rgba(255, 99, 132, 0.5)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        function togglePeriod(period, chartType) {
            document.querySelectorAll(`#${chartType} .toggle-buttons button`).forEach(button => {
                button.classList.toggle('active', button.id.includes(period));
            });
            drawHHOChart(period);
            drawBranchClassCharts(period);
        }

        function showTab(slideId) {
            document.querySelectorAll('.tab-content').forEach(slide => {
                slide.style.display = 'none';
            });
            document.getElementById(slideId).style.display = 'block';
            document.querySelectorAll('.tabs button').forEach(button => {
                button.classList.remove('active');
            });
            document.getElementById(`tab${slideId.charAt(slideId.length - 1)}`).classList.add('active');
        }
